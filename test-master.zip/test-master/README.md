<div align="center">

# oyvey-ported
Kosher client base ported to Minecraft 1.21.5 by [@cattyngmd](https://github.com/cattyngmd)

<img src="https://i.imgur.com/Lu6rDJB.png" width="90%" />

# Why
![](https://i.imgur.com/VYjIphG.png)

# Skid???
Used this based client base for a **skidding** tutorial\
\
[![Knowledge is power](https://img.youtube.com/vi/lCWfu0gOE0c/hqdefault.jpg)](https://www.youtube.com/watch?v=lCWfu0gOE0c)

</div>
