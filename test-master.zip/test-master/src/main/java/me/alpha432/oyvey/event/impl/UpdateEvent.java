package me.alpha432.oyvey.event.impl;

import me.alpha432.oyvey.event.Event;

public class UpdateEvent extends Event {
}
