package me.alpha432.oyvey.event;

public enum Stage {
    PRE,
    POST;
}
